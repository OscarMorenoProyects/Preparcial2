public class TestFactory {
    public static void main(String[] args) {

        ContenidoFactory f1 = new CancionFactory();
        ContenidoFactory f2 = new PodcastFactory();
        ContenidoFactory f3 = new AudiolibroFactory();

        Contenido c1 = f1.crearContenido("1", "Shape of You", 200, "Ed Sheeran", "Divide");
        Contenido c2 = f2.crearContenido("2", "TechTalk", 1800, "Juan", "5");
        Contenido c3 = f3.crearContenido("3", "El Quijote", 5000, "Cervantes", "Pedro");

        c1.reproducir();
        c2.reproducir();
        c3.reproducir();
    }
}