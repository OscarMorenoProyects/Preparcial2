public class TestDecorator {
    public static void main(String[] args) {

        Contenido c = new Cancion("1", "Song", 200, "A", "X");

        IReproductor r = new Efecto8D(
                new ReverbEfecto(
                        new EqEfecto(
                                new ReproductorBase()
                        )
                )
        );

        r.reproducir(c);
    }
}