public class TestSingleton {
    public static void main(String[] args) {
        ReproductorGlobal r1 = ReproductorGlobal.getInstancia();
        ReproductorGlobal r2 = ReproductorGlobal.getInstancia();

        if (r1 == r2) {
            System.out.println("Singleton funciona: misma instancia");
        } else {
            System.out.println("Error: instancias diferentes");
        }
    }
}