public interface ComponentePlaylist {
    int duracionTotal();
    void mostrar(String indent);
}