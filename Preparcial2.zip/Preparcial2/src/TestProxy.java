public class TestProxy {
    public static void main(String[] args) {

        Usuario free = new Usuario("1", "Oscar", Usuario.TipoSuscripcion.FREE);
        Usuario premium = new Usuario("2", "Ana", Usuario.TipoSuscripcion.PREMIUM);

        Contenido cancion = new Cancion("1", "Song", 200, "A", "X");
        Contenido libro = new Audiolibro("2", "Libro", 5000, "Autor", "Narrador");

        IReproductor base = new ReproductorBase();

        IReproductor proxyFree = new ProxyReproductor(base, free);
        IReproductor proxyPremium = new ProxyReproductor(base, premium);

        System.out.println("---- FREE ----");
        proxyFree.reproducir(cancion);
        proxyFree.reproducir(libro);

        System.out.println("---- PREMIUM ----");
        proxyPremium.reproducir(libro);
    }
}