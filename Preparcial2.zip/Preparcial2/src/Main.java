public class Main {
    public static void main(String[] args) {

        Usuario user = new Usuario("1", "Oscar", Usuario.TipoSuscripcion.FREE);

        // Factory
        ContenidoFactory factory = new CancionFactory();
        Contenido c = factory.crearContenido("1", "Song", 200, "A", "X");

        // Composite
        Playlist p = new Playlist("Mi Playlist");
        p.agregar(new ElementoContenido(c));

        // Decorator + Proxy
        IReproductor r = new ProxyReproductor(
                new ReverbEfecto(
                        new ReproductorBase()
                ),
                user
        );

        p.mostrar("");
        r.reproducir(c);
    }
}