public class TestComposite {
    public static void main(String[] args) {

        Contenido c1 = new Cancion("1", "Song1", 200, "A", "X");
        Contenido c2 = new Cancion("2", "Song2", 300, "B", "Y");

        Playlist p1 = new Playlist("Playlist 1");
        p1.agregar(new ElementoContenido(c1));

        Playlist p2 = new Playlist("Playlist 2");
        p2.agregar(new ElementoContenido(c2));

        Playlist general = new Playlist("General");
        general.agregar(p1);
        general.agregar(p2);

        general.mostrar("");
        System.out.println("Duración total: " + general.duracionTotal());
    }
}